We have made use of the commons-csv-1.6.jar in our implementation. Thus, we have created a runnable jar of our program (SMP.jar) that includes this and all of our lib dependencies.

To run SMP please specify SMP.jar as the classpath in the command like so:

java -cp SMP.jar SMP <input_file> <m/w>
